import React from 'react';
import Navbar from 'react-bootstrap/Navbar';
import Nav from 'react-bootstrap/Nav';
import Button from 'react-bootstrap/Button';


class UserDetails extends React.Component {

  render() {
    return (

    <Navbar bg="primary" variant="dark" className="navbar navbar-dark bg-info">
   
    <Nav className="mr-auto">  
       <h6>Welcome : <label className="text-dark font-weight-bold">User</label></h6>
    </Nav>
    <Nav className="mr-auto">  
       <h6>Last Login : <label className="text-dark font-weight-bold">2020/08/13 12:30:44</label></h6>
    </Nav>
     <Nav>
      
      <Nav.Link href="#Singout"><label className="font-weight-bold">Signout</label></Nav.Link>
    
    </Nav>
  </Navbar>

    );
  }
}
export default UserDetails;