import React from 'react';

class HeaderLogin extends React.Component {
   render() {

         return (   // Render fucction is life cycle hook which render template
          
         <nav className="navbar navbar-dark bg-secondary">
            <div className="row col-12 d-flex justify-content-center text-white">
               <span className="h3">CLAIM MANAGEMENT SYSTEM</span>
             </div>
         </nav>
      );
   }
}

export default HeaderLogin; 




