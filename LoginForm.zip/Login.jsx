import React, { Component } from 'react';
import { render } from 'react-dom';




class Login extends Component {
    
   /*  handleClick(event) {
      
        event.preventDefault();
        var change = {};
        change[name] = event.target.value;
        console.log('this is:', event.target.name);
      } */
      handleClick = (event) => {
        console.log('Event fired')
        event.preventDefault();
        const { name, value } = event.type.name;
        let errors = this.state.errors;
        console.log(this.name);
      /*   switch (name) {
          case 'fullName': 
            errors.fullName = 
              value.length < 5
                ? 'Full Name must be 5 characters long!'
                : '';
            break;
          case 'email': 
            errors.email = 
              validEmailRegex.test(value)
                ? ''
                : 'Email is not valid!';
            break;
          case 'password': 
            errors.password = 
              value.length < 8
                ? 'Password must be 8 characters long!'
                : '';
            break;
          default:
            break;
        }
    
        this.setState({errors, [name]: value}, ()=> {
          console.log(errors)
        }) */
      }

  render() {
    return (
      <div >
        <div>
          <h2>Register</h2>
          <form noValidate >
            <div >
              <label htmlFor="fullName">Full Name</label>
              <input type='text' name='fullName' onChange={this.handleClick} noValidate />
            </div>
          
            <div >
              <label htmlFor="password">Password</label>
              <input type='password' name='password' onChange={this.handleClick} noValidate />
            </div>
            <div >
              <small>Password must be eight characters in length.</small>
            </div>
            <div >
              <button>Create</button>
            </div>
          </form>
        </div>
      </div>
    );
  }
};


export default Login;