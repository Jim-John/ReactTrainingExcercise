import React from 'react';
import Table from 'react-bootstrap/Table';
import Button from 'react-bootsrap/Button';

class LoginForm extends React.Component {

  render() {

    return(

      <Table striped bordered hover>
        <tbody>
        <tr>
          <td>
              Username
          </td>
          <td>
          <input type="text" name="uname" id="uname"/>
          </td>
        </tr>
        
        <tr>
          <td>
            Password
          </td>
          <td>
            <input type="password" name="pass" id="pass"/>
          </td>
        </tr>
        <tr>
          <td>
            <input type="button" value="Login" onClick="validateCreds();"/>
          </td>
          <td>
            <input type="reset" name="Cancel"/>
          </td>
        </tr>
        <tr>
          <td colSpan="2">
            <div id="messageDiv" className="errorMsg"></div>
          </td>
        </tr>
        </tbody>
      </Table>
  );
 }    
}
export default LoginForm;