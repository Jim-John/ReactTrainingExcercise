import React from 'react';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

class LoginForm extends React.Component {

  render() {

    return (

      <Container>
        <Form>
          <Row className="justify-content-md-center align-items-center">
            <Col >
              <Form.Group controlId="formBasicUsername">
                <Form.Label>Username</Form.Label>
                <Form.Control type="text" placeholder="Username" />
              </Form.Group>
            </Col>

          </Row>
          <Row>
            <Col>
              <Form.Group controlId="formBasicPassword">
                <Form.Label>Password</Form.Label>
                <Form.Control type="password" placeholder="Password" />
              </Form.Group></Col>

          </Row>
          <Row className="mx-auto">
            <Col md={{ span: 3, offset: 3 }}>
              <Form.Row md="2">
                

                <Button variant="primary" type="submit">
                  Submit
                </Button>
              </Form.Row>
            </Col>
          </Row>
        </Form>
      </Container>







    );
  }
}
export default LoginForm;