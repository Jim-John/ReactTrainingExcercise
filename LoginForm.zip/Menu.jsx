import React from 'react';
import Nav from 'react-bootstrap/Nav';

class Menu extends React.Component {

	render() {
    return(
     
      <Nav variant="pills" defaultActiveKey="/home" className="navbar navbar-dark bg-secondary">
        <Nav.Item>
          <Nav.Link href="/home">Home</Nav.Link>
        </Nav.Item>
        <Nav.Item>
          <Nav.Link eventKey="link-1">Claim Summary</Nav.Link>
        </Nav.Item>
        <Nav.Item>
          <Nav.Link eventKey="link-2">Update Claim Summary</Nav.Link>
        </Nav.Item>
        <Nav.Item>
          <Nav.Link eventKey="ilink-3">About Us</Nav.Link>
        </Nav.Item>
        <Nav.Item>
          <Nav.Link eventKey="ilink-4">Contact Us</Nav.Link>
        </Nav.Item>
      </Nav>
     );
  }
}
export default Menu;