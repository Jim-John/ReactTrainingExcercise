import React from 'react'; 
import ReactDOM from 'react-dom'; 
import Header from './HeaderLogin.jsx';
import Footer from './Footer.jsx'
import LoginForm from './LoginForm.jsx'
import ClaimForm from './ClaimSummary.jsx'
import Menu from './Menu.jsx'
import User from './UserDetails.jsx'
import Login from './Login.jsx'



ReactDOM.render(<Login/>, document.getElementById('body'));


/*
ReactDOM.render(<LoginForm/>, document.getElementById('body'));
ReactDOM.render(<Header/>, document.getElementById('header'));
ReactDOM.render(<User/>, document.getElementById('user'));
ReactDOM.render(<Menu/>, document.getElementById('menu'));
ReactDOM.render(<ClaimForm/>, document.getElementById('claimSummary'));
ReactDOM.render(<Footer/>, document.getElementById('footer')); 
 */

